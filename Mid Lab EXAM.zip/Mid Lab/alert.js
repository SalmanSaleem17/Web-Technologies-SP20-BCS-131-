function fun() {  
    alert ("MUHAMMAD SALMAN SALEEM (SP20-BCS-131)");  
 }  