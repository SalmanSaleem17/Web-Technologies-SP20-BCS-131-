# Electronics shop

DB Conectivty
Form Validation
Authentication
Landing Page
Admin Panel
